// init Countries object
const countries = new Countries();
// init UI object
const ui = new UI();
//init cart Object
const cart = new Cart();
// init Payment Object
const payment = new Payment();

// fetch and display countries from json file once DOM has loaded
document.addEventListener('DOMContentLoaded', e =>{
    ui.displayHeader();
    countries.getCountries()
    .then(allCountries => ui.displayCountries(allCountries))
});
document.getElementById('red-box').addEventListener('click', e => {
    ui.unDisablebtn();
    document.getElementById('redCheckbox').checked = true;
    e.preventDefault();
});
document.getElementById('blue-box').addEventListener('click', e => {
    ui.unDisablebtn();
    document.getElementById('blueCheckbox').checked = true;
    e.preventDefault();
});
document.getElementById('orange-box').addEventListener('click', e => {
    ui.unDisablebtn();
    document.getElementById('orangeCheckbox').checked = true;
    e.preventDefault();
});
document.getElementById('green-box').addEventListener('click', e => {
    ui.unDisablebtn();
    document.getElementById('greenCheckbox').checked = true;
    e.preventDefault();
});

document.getElementById('anotherItem').addEventListener('click', e => {
    cart.addItem();
    let itemQuantity = cart.item;
    if(itemQuantity){
        if(itemQuantity === 'red')
            itemQuantity = cart.red.quantity;
        else if (itemQuantity === 'blue')
            itemQuantity = cart.blue.quantity;
        else if(itemQuantity === 'orange')
            itemQuantity = cart.orange.quantity;
        else 
            itemQuantity = cart.green.quantity;
    ui.addItemToCart
    (cart.item,
    itemQuantity,
    cart.colorSubTotal,
    cart.subTotal.string,
    cart.cartTotal.string,
    cart.quantity.total);
    }

    e.preventDefault();
});

document.getElementById('clear-btn').addEventListener('click', e => {
    ui.clear();
    cart.reset();
    payment.clear();
    e.preventDefault();
})

document.getElementById('payment-btn').addEventListener('click', e => {
    if(!cart.isCartEmpty){
        payment.checkFields(ui.countries);
        // e.preventDefault();
    }else
        alert('Cart Is Empty');
})
document.getElementById('creditCardNumber').addEventListener('input', e => {
    payment.checkCreditCardNumber(e);
    e.preventDefault();
})
document.getElementById('securityCode').addEventListener('input', e => {
    payment.checkSecurityNumber(e);
    e.preventDefault();
})
document.getElementById('cardExperationMonth').addEventListener('input', e => {
    payment.checkMonth(e);
    e.preventDefault();
})
document.getElementById('cardExperationYear').addEventListener('input', e => {
    payment.checkYear(e)
    e.preventDefault();
})



