class Payment {
    constructor(){
        this.paymentInfo = {
            firstName: document.getElementById('firstName'),
            lastName: document.getElementById('lastName'),
            creditCardNumber: document.getElementById('creditCardNumber'),
            creditCardNumberActual: '',
            securityCode: document.getElementById('securityCode'),
            experationMonth: document.getElementById('cardExperationMonth'),
            expirationYear: document.getElementById('cardExperationYear')
        };

        this.shippingInfo = {
            streetAddress: document.getElementById('streetAddress'),
            streetAddressLine2: document.getElementById('streetAddressLine2'),
            city: document.getElementById('city'),
            state: document.getElementById('state'),
            postalCode: document.getElementById('postalCode'),
            country: document.getElementById('country')
        }
        this.email = document.getElementById('e-mail')
        this.date = new Date();
        this.today = new Date();
        this.deliveryDate;

    }
    checkFields(countries) {
        console.log('Hello');
        let passed = false;
        if(this.paymentInfo.firstName.value === '')
            this.paymentInfo.firstName.style.border = 'solid 1px red ';
        else{
            this.paymentInfo.firstName.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.paymentInfo.lastName.value === '')
            this.paymentInfo.lastName.style.border = 'solid 1px red ';
        else{
            this.paymentInfo.lastName.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.paymentInfo.creditCardNumber.value === '')
            this.paymentInfo.creditCardNumber.style.border = 'solid 1px red ';
        else{
            this.paymentInfo.creditCardNumber.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.paymentInfo.securityCode.value === '')
            this.paymentInfo.securityCode.style.border = 'solid 1px red ';
        else{
            this.paymentInfo.securityCode.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.paymentInfo.experationMonth.value === '')
            this.paymentInfo.experationMonth.style.border = 'solid 1px red ';
        else{
            this.paymentInfo.experationMonth.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.paymentInfo.expirationYear.value === '')
            this.paymentInfo.expirationYear.style.border = 'solid 1px red ';
        else{
            this.paymentInfo.experationMonth.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.shippingInfo.streetAddress.value === '')
            this.shippingInfo.streetAddress.style.border = 'solid 1px red ';
        else{
            this.shippingInfo.streetAddress.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.shippingInfo.city.value === '')
            this.shippingInfo.city.style.border = 'solid 1px red ';
        else{
            this.shippingInfo.city.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.shippingInfo.state.value === '')
            this.shippingInfo.state.style.border = 'solid 1px red ';
        else{
            this.shippingInfo.state.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.shippingInfo.postalCode.value === '')
            this.shippingInfo.postalCode.style.border = 'solid 1px red ';
        else{
            this.shippingInfo.postalCode.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.shippingInfo.country.value === '' || this.checkCountry(countries) === false){
            this.shippingInfo.country.style.border = 'solid 1px red ';
        }else{
            this.shippingInfo.country.style.border = '#CCC solid 1px';
            passed = true;
        }

        if(this.email.value === '')
            this.email.style.border = 'solid 1px red ';
        else{
            this.email.style.border = '#CCC solid 1px';
            passed = true;
        } 
        if (passed){
            this.deliveryDate = this.today.getDate();
            console.log(passed);
            
            // ui.displayDeliveryDate();
        }
    }     
    
    checkCountry(countries){
        console.log(this.shippingInfo.country.value);
        let isCountry = false
        countries.forEach(country => {
            if(this.shippingInfo.country.value == country.name){
                isCountry = true;
            }
        });
        if(!isCountry){
            this.shippingInfo.country.value = '';
        }
        return isCountry;
    }
    
    checkCreditCardNumber(e) {
        let creditCardNumber = this.paymentInfo.creditCardNumber.value;
        if(e.data != null){
            if (isNaN(e.data) || creditCardNumber.length == 20)
                this.paymentInfo.creditCardNumber.value = creditCardNumber.slice(0, this.paymentInfo.creditCardNumber.value.length-1);
            else{
                if (creditCardNumber.length == 4){
                    this.paymentInfo.creditCardNumberActual = creditCardNumber;
                    this.paymentInfo.creditCardNumber.value += '_';
                }else if(creditCardNumber.length == 9){
                    this.paymentInfo.creditCardNumberActual += creditCardNumber.slice(5,9);
                    this.paymentInfo.creditCardNumber.value += '_';    
                }else if(creditCardNumber.length == 14){
                    this.paymentInfo.creditCardNumberActual += creditCardNumber.slice(10,14);
                    this.paymentInfo.creditCardNumber.value += '_';        
                }else if(creditCardNumber.length == 19){
                    this.paymentInfo.creditCardNumberActual += creditCardNumber.slice(15,19);   
                }
            }
        }
    }

    checkSecurityNumber(e) {
        let securityCode = this.paymentInfo.securityCode.value
        if(e.data != null){
            if (isNaN(e.data) || securityCode.length == 4)
                this.paymentInfo.securityCode.value = securityCode.slice(0, this.paymentInfo.securityCode.value.length-1);
        }
    }

    checkMonth(e){
        let month = this.paymentInfo.experationMonth.value
        if(e.data != null){
            if (isNaN(e.data) || month > 12 || month < 1)
                this.paymentInfo.experationMonth.value = month.slice(0, this.paymentInfo.experationMonth.value.length-1);
                // alert('Must be a number Between 1 and 12')
        }        
    }
    checkYear(e){
        let year = this.paymentInfo.expirationYear.value
        console.log(this.date.getFullYear());
        
        if(e.data != null){
            if (isNaN(e.data) || year.length > 4)
                this.paymentInfo.expirationYear.value = year.slice(0, this.paymentInfo.expirationYear.value.length-1);
            else if (year.length == 4){
                
                if (year < this.date.getFullYear() || year> (this.date.getFullYear()+5)){
                    console.log('Hello');
                    this.paymentInfo.expirationYear.style.border = 'solid 1px red ';
                }else if (year == this.date.getFullYear()){
                    this.paymentInfo.expirationYear.style.border = '#CCC solid 1px';
                }
            }
            else{
                console.log('Yo');

                this.paymentInfo.expirationYear.style.border = '#CCC solid 1px';
            }

                // alert('Must be a number Between 1 and 12')
        }        
    }
    

    clear(){
        this.paymentInfo.firstName.value = '';
        this.paymentInfo.lastName.value = '';
        this.paymentInfo.creditCardNumber.value = '';
        this.paymentInfo.securityCode.value = '';
        this.paymentInfo.experationMonth.value = '';
        this.paymentInfo.expirationYear.value = '';

        this.shippingInfo.streetAddress.value = '';
        this.shippingInfo.streetAddressLine2.value = '';
        this.shippingInfo.city.value = '';
        this.shippingInfo.state.value = '';
        this.shippingInfo.postalCode.value = '';
        this.shippingInfo.country.value = '';

        this.paymentInfo.firstName.style.border = '#CCC solid 1px';
        this.paymentInfo.lastName.style.border = '#CCC solid 1px';
        this.paymentInfo.creditCardNumber.style.border = '#CCC solid 1px';
        this.paymentInfo.securityCode.style.border = '#CCC solid 1px';
        this.paymentInfo.experationMonth.style.border = '#CCC solid 1px';
        this.paymentInfo.expirationYear.style.border = '#CCC solid 1px';

        this.shippingInfo.streetAddress.style.border = '#CCC solid 1px'
        this.shippingInfo.city.style.border = '#CCC solid 1px'
        this.shippingInfo.state.style.border = '#CCC solid 1px'
        this.shippingInfo.postalCode.style.border = '#CCC solid 1px'
        this.shippingInfo.country.style.border = '#CCC solid 1px'

        this.email.style.border = '#CCC solid 1px'
    }

    
}