class Cart {
    constructor(){
        this.quantity = {
            currentQuantity: 0,
            total: 0
        };
        this.items; // html collection of document.getElementsByName('item');
        this.item; // string of the selected item ex: 'red'
        this.cartTotal = {
            string: '',
            total: 0
        };
    
        this.subTotal = {
            string: '', 
            total: 0
        };
        
        this.red = {
            quantity: 0,
            total: 0,
            string: ''
        };
        this.blue = {
            quantity: 0,
            total: 0,
            string: '' 
        };
        this.orange = {
            quantity: 0,
            total: 0,
            string: ''
        };
        this.green = {
            quantity: 0,
            total: 0,
            string: ''
        };

        this.colorSubTotal = '';
        this.isCartEmpty = true;
    }
    
    addItem(){
        this.isCartEmpty = false;
        this.quantity.currentQuantity = parseFloat(document.getElementById('item-quantity').value);
        
        const item = this.checkItems();

        if (item){
            this.subTotal.total += this.quantity.currentQuantity*item;
            this.cartTotal.total = this.subTotal.total*1.13;
    
            let stringTot = this.cartTotal.total.toString();
            let stringSubTot = this.subTotal.total.toString();
    
            stringTot = this.checkRound(stringTot);
            this.cartTotal.string = stringTot;
            
            stringSubTot = this.checkRound(stringSubTot);
            this.subTotal.string = stringSubTot;
        }
    }

    checkRound (string) {
        const indexOfDecimal = parseFloat(string.indexOf('.'));
        let decimals = string.slice(indexOfDecimal+1, string.length);
        let nonDecimals = string.slice(0, indexOfDecimal);
        const numToCheck = decimals.slice(2, 3);
        
        if(decimals.length >= 3){
            decimals = decimals.slice(0, 3);
            if (numToCheck > 4){
                return this.roundDecOrNonDec(decimals, nonDecimals);
            }else{
                return nonDecimals + '.' + decimals.slice(0, 2);
            }
        }else {
            return string;
        }
    }

    roundDecOrNonDec(decimals, nonDecimals){
        decimals = decimals.slice(0, 2);
        if (decimals == '99'){
            decimals = '00';
            nonDecimals = this.roundNum(nonDecimals);
            return nonDecimals + '.' + decimals;
        } else {
            decimals = this.roundNum(decimals);
            return nonDecimals + '.' + decimals;
        }
    }
    
    roundNum (number) {
        let indexToCheck = number.length -1;
        let newNumber;
        let newString = '';
        
        while (indexToCheck != -1){
            if (number.charAt(indexToCheck) != 9 || indexToCheck == 0){
                newNumber = parseFloat(number.charAt(indexToCheck)) +1 
                for(let i = 0; i < number.length; i++){
                    if (i == indexToCheck)
                        newString += newNumber;
                        else
                            newString += number.charAt(i);
                }
                return newString;
            }else {
                let tempString = '';
                for(let i = 0; i < number.length; i++){
                    
                    if (i == indexToCheck){
                        tempString += '0';
                    }else
                    tempString += number.charAt(i); 
                }
                number = tempString;
                indexToCheck--;
            }
        }
    }

    checkItems(){
        this.items = document.getElementsByName('item');
        for(let i=0; i<this.items.length; i++){
            if(this.items[i].checked){
                let totString;
                if(i==0){
                    if(this.red.quantity === 10){
                        this.item = '';
                        return '';
                    }
                    this.red.total += this.items[i].value * this.quantity.currentQuantity;
                    this.red.quantity += parseFloat(this.quantity.currentQuantity);
                    totString = this.red.total.toString();
                        this.red.string = this.checkRound(totString);
                        this.colorSubTotal = this.red.string;
                        this.item = 'red';    
                }else if (i==1){
                    if(this.blue.quantity === 10){
                        this.item = '';
                        return '';
                    }
                    this.blue.total += this.items[i].value * this.quantity.currentQuantity;
                    this.blue.quantity += parseFloat(this.quantity.currentQuantity);
                    totString = this.blue.total.toString();
                    this.blue.string = this.checkRound(totString);
                    this.colorSubTotal = this.blue.string;
                    this.item = 'blue';
                }else if (i==2){
                    if(this.orange.quantity === 10){
                        this.item = '';
                        return '';
                    }
                    this.orange.total += this.items[i].value * this.quantity.currentQuantity;
                    this.orange.quantity += parseFloat(this.quantity.currentQuantity);
                    totString = this.orange.total.toString();
                    this.orange.string = this.checkRound(totString);
                    this.colorSubTotal = this.orange.string;
                    this.item = 'orange';
                }else if (i==3){
                    if(this.green.quantity === 10){
                        this.item = '';
                        return '';
                    }
                    this.green.total += this.items[i].value * this.quantity.currentQuantity;
                    this.green.quantity += parseFloat(this.quantity.currentQuantity);
                    totString = this.green.total.toString();
                    this.green.string = this.checkRound(totString);
                    this.colorSubTotal = this.green.string;
                    this.item = 'green';
                }
                this.quantity.total += this.quantity.currentQuantity;
                return this.items[i].value; // Example: 19.99"
            }
        }
    }
    reset(){
        this.cartTotal.total = 0;
        this.cartTotal.string = '';

        this.subTotal.total = 0;
        this.subTotal.string = '';

        this.quantity.currentQuantity = 0;
        this.quantity.total = 0;
        
        this.red.total = 0;
        this.red.quantity = 0;
        this.red.string = '';
        
        this.blue.total = 0;
        this.blue.quantity = 0;
        this.blue.string = '';
        
        this.orange.total = 0;
        this.orange.quantity = 0;
        this.orange.string = '';
        
        this.green.total = 0;
        this.green.quantity = 0;
        this.green.string = '';
        
        this.colorSubTotal = '';

        this.isCartEmpty = true;
    }
}